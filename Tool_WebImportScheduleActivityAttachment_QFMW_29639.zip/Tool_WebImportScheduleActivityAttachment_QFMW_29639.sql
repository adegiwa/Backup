


GO
Tool_DropObject 'Tool_WebImportScheduleActivityAttachment','P'

GO
CREATE PROC [dbo].[Tool_WebImportScheduleActivityAttachment]  
@AttachmentID int,  
@FileName nvarchar(MAX), 
@ScheduleActivityReferenceList nvarchar(MAX),             
@Caption nvarchar(MAX),                              
@Remarks nvarchar(MAX)= NULL,             
@DocumentTypeID INT,                    
@FuncAreaID int,                  
@AudienceID int,                   
@EditorsID int,                   
@AttachmentURL nvarchar(100) ,                        
@EntityID int,              
@StartDateUTC DateTime = NULL,             
@EndDateUTC DateTime = NULL,             
@Metadata nvarchar(MAX)= NULL,             
@SystemMetaDatatags nvarchar(MAX)= NULL,
@comment nvarchar(MAX) OUTPUT

AS

DECLARE @ScheduleActivityID INT
DECLARE @Revision INT


IF (ISNULL(@ScheduleActivityReferenceList,'')<>'')  
BEGIN

	DECLARE @start INT = 1;
	DECLARE @comma INT;
	SELECT @comment = '';  

	WHILE @start < LEN(@ScheduleActivityReferenceList)
	BEGIN
		SET @comma = CHARINDEX(',', @ScheduleActivityReferenceList, @start);
		IF @comma = 0 SET @comma = LEN(@ScheduleActivityReferenceList) + 1;

		SET @ScheduleActivityID = SUBSTRING(@ScheduleActivityReferenceList, @start, @comma - @start)
		SET @EntityID = @ScheduleActivityID
		if ISNULL(@AttachmentID,0) =0        
		Begin        
		 select @AttachmentID =AttachmentID from Attachment a where Source=@FileName and @EntityID=a.AttachmentRef and @FuncAreaID=a.FuncAreaID                    
		end                    
		if  @AttachmentID IS not null          
		Begin        
		 SELECT @Revision = a.Revision from attachment a where a.AttachmentID =@AttachmentID                    
		End         
        
		if isnull(@Revision,0)>0                     
		Begin
		  set @comment=@comment+ ',Cannot update an attachment link for file which is already uploaded'  
		  RETURN 
		End

           
		if  isnull( @AttachmentID,0)=0 -- add                    
		BEGIN                    
		 EXEC [dbo].[qfm_GetKeyValue] @BaseTableName=N'Attachment',@Increment=1,@NextKeyID = @AttachmentID output;                    
                    
		 insert into Attachment (DocumentTypeID, Name,AttachmentID,AttachmentTypeID,AttachmentTypeName, Source, FuncAreaID,AttachmentRef, AudienceGroupID, AuthorGroupID, EndDate,                 
		 StartDate, Remarks, MetaData, SystemMetaDataTags, Revision,InsertUser,InsertStamp,[Path] )                     
		 values (@DocumentTypeID,@Caption,@AttachmentID,4,'URL', @FileName, @FuncAreaID,@EntityID, @AudienceID,@EditorsID, @EndDateUTC, @StartDateUTC, @Remarks, @MetaData, @SystemMetaDataTags, 0,'swgimport', GETUTCDATE(),@AttachmentURL)                                     

		 SET @AttachmentID = 0
		end                    
		else                    
		 update Attachment set                     
		 DocumentTypeID=@DocumentTypeID,                    
		 Source=@FileName,                    
		 Name=@Caption,                    
		 FuncAreaID= @FuncAreaID,                    
		 AttachmentRef=@EntityID,                     
		   AudienceGroupID= @AudienceID,                    
		   AuthorGroupID= @EditorsID,                     
		   EndDate=@EndDateUTC,                    
		   StartDate= @StartDateUTC,                     
		   Remarks=@Remarks,                     
		   MetaData=@MetaData,                     
		   SystemMetaDataTags= @SystemMetaDataTags  ,                  
		   UpdateUser='swgimport',                  
		   UpdateStamp = GETUTCDATE()                  
		 where AttachmentID=@AttachmentID 

		 SET @AttachmentID = 0

		 SET @start = @comma + 1;
	END;
	IF (ISNULL(@comment,'') = '')
	Begin
		set @comment=@comment + 'OK'
	RETURN
    End


END

GO
GO
Tool_DropObject 'Tool_WebImportScheduleAttachment','P'

GO
CREATE PROC [dbo].[Tool_WebImportScheduleAttachment]  
@AttachmentID int,  
@FileName nvarchar(MAX), 
@ScheduleReferenceList nvarchar(MAX),             
@Caption nvarchar(MAX),                              
@Remarks nvarchar(MAX)= NULL,             
@DocumentTypeID INT,                    
@FuncAreaID int,                  
@AudienceID int,                   
@EditorsID int,                   
@AttachmentURL nvarchar(100) ,                        
@EntityID int,              
@StartDateUTC DateTime = NULL,             
@EndDateUTC DateTime = NULL,             
@Metadata nvarchar(MAX)= NULL,             
@SystemMetaDatatags nvarchar(MAX)= NULL,
@comment nvarchar(MAX) OUTPUT

AS

DECLARE @ScheduleID INT
DECLARE @Revision INT


IF (ISNULL(@ScheduleReferenceList,'')<>'')  
BEGIN

	DECLARE @start INT = 1;
	DECLARE @comma INT;
	SELECT @comment = '';  

	WHILE @start < LEN(@ScheduleReferenceList)
	BEGIN
		SET @comma = CHARINDEX(',', @ScheduleReferenceList, @start);
		IF @comma = 0 SET @comma = LEN(@ScheduleReferenceList) + 1;

		SET @ScheduleID = SUBSTRING(@ScheduleReferenceList, @start, @comma - @start)
		SET @EntityID = @ScheduleID
		if ISNULL(@AttachmentID,0) =0        
		Begin        
		 select @AttachmentID =AttachmentID from Attachment a where Source=@FileName and @EntityID=a.AttachmentRef and @FuncAreaID=a.FuncAreaID                    
		end                    
		if  @AttachmentID IS not null          
		Begin        
		 SELECT @Revision = a.Revision from attachment a where a.AttachmentID =@AttachmentID                    
		End         
        
		if isnull(@Revision,0)>0                     
		Begin
		  set @comment=@comment+ ',Cannot update an attachment link for file which is already uploaded'  
		  RETURN 
		End

           
		if  isnull( @AttachmentID,0)=0 -- add                    
		BEGIN                    
		 EXEC [dbo].[qfm_GetKeyValue] @BaseTableName=N'Attachment',@Increment=1,@NextKeyID = @AttachmentID output;                    
                    
		 insert into Attachment (DocumentTypeID, Name,AttachmentID,AttachmentTypeID,AttachmentTypeName, Source, FuncAreaID,AttachmentRef, AudienceGroupID, AuthorGroupID, EndDate,                 
		 StartDate, Remarks, MetaData, SystemMetaDataTags, Revision,InsertUser,InsertStamp,[Path] )                     
		 values (@DocumentTypeID,@Caption,@AttachmentID,4,'URL', @FileName, @FuncAreaID,@EntityID, @AudienceID,@EditorsID, @EndDateUTC, @StartDateUTC, @Remarks, @MetaData, @SystemMetaDataTags, 0,'swgimport', GETUTCDATE(),@AttachmentURL)                                     

		 SET @AttachmentID = 0
		end                    
		else                    
		 update Attachment set                     
		 DocumentTypeID=@DocumentTypeID,                    
		 Source=@FileName,                    
		 Name=@Caption,                    
		 FuncAreaID= @FuncAreaID,                    
		 AttachmentRef=@EntityID,                     
		   AudienceGroupID= @AudienceID,                    
		   AuthorGroupID= @EditorsID,                     
		   EndDate=@EndDateUTC,                    
		   StartDate= @StartDateUTC,                     
		   Remarks=@Remarks,                     
		   MetaData=@MetaData,                     
		   SystemMetaDataTags= @SystemMetaDataTags  ,                  
		   UpdateUser='swgimport',                  
		   UpdateStamp = GETUTCDATE()                  
		 where AttachmentID=@AttachmentID 

		 SET @AttachmentID = 0

		 SET @start = @comma + 1;
	END;
	IF (ISNULL(@comment,'') = '')
	Begin
		set @comment=@comment + 'OK'
	RETURN
    End


END

GO

GO
Tool_DropObject 'Tool_WebImportAttachmentLinksV2','P'

GO
CREATE PROC [dbo].[Tool_WebImportAttachmentLinksV2]                      
@AttachmentID int,             
@FileName nvarchar(MAX),             
@Caption nvarchar(MAX),             
@EntityType nvarchar(MAX),             
@LookupValue nvarchar(MAX),             
@Remarks nvarchar(MAX)= NULL,             
@DocumentType nvarchar(MAX)= NULL,             
@StartDateUTC DateTime = NULL,             
@EndDateUTC DateTime = NULL,             
@Metadata nvarchar(MAX)= NULL,             
@SystemMetaDatatags nvarchar(MAX)= NULL,             
@AudienceGroup nvarchar(MAX)= NULL,             
@EditorGroup nvarchar(MAX)= NULL,             
@Remove int = 0                     
AS                      
SET NOCOUNT ON;                      
                    
DECLARE @comment NVARCHAR (MAX);                      
declare @msg nvarchar(max)                    
declare @Revision int                    
                    
SELECT @comment = '';                      
DECLARE @DocumentTypeID int;                    
DECLARE @FuncAreaID int;                    
DECLARE @AudienceID int;                    
DECLARE @EditorsID int ;                    
DECLARE @AttachmentURL nvarchar(100)                          
declare @entityID int               
    
declare @lastSlash int      
declare @nextSlash int      
declare @origfilePart nvarchar(max)      
declare @shortFileName  nvarchar(max)      
declare @delim nvarchar(20)='_'      
DECLARE @returnComment VARCHAR(100) 
set @nextSlash=-1      
      
findLast:      
set @nextSlash=CHARINDEX('\',@FileName,@nextSlash+1)      
if not @nextSlash is null and @nextSlash<>0      
begin       
   set @lastSlash=@nextSlash      
   GOTO findlast      
END      
      
if @lastSlash>0      
set @shortFileName=substring(@filename,@lastSlash+1, len(@fileName)-@lastSlash)      
ELSE      
SET @shortFileName=@filename      
      
declare @lastDot int      
DECLARE @nextDot int      
set @lastDot =0      
set @nextDot=-1      
      
findLastDec:      
set @nextDot=CHARINDEX('.',@FileName,@nextDot+1)      
if not @nextDot is null and @nextDot<>0      
begin       
   set @lastDot=@nextDot      
   --print @lastDot      
   goto findLastDec      
end      
      
      
declare @lastDelim int      
declare @nextDelim int      
set @nextDelim=-1      
      
findLastDelim:      
set @nextDelim=CHARINDEX(@delim,@FileName,@nextDelim+1)      
if not @nextDelim is null and @nextDelim<>0      
begin       
   set @lastDelim=@nextDelim      
   --print @lastDelim      
   goto findLastDelim      
end      
      
declare @version nvarchar(20)      
declare @ext nvarchar(20)      
set @ext=''      
if @lastDelim<>0 set @version=substring(@fileName,@lastDelim,len(@fileName)-@lastDelim)      
if @lastDot<> 0  set @ext = substring(@fileName,@lastDot,len(@fileName)-@lastDot+1)-- extension      
      
if @lastDelim>0      
BEGIN      
       set @origfilePart=substring(@fileName,1,@lastDelim-1)+@ext      
    set @shortFileName=substring(@origfilePart,@lastSlash+1, len(@origfilePart)-@lastSlash)      
END      
ELSE      
BEGIN      
       set @origfilePart=@fileName      
END      
      
SET @fileName = @origfilePart    
    
    
    
if (ISNULL(@AttachmentID,0)= 0) and isnull(@FileName,'') =''                 
begin                    
set @comment='An AttachmentID or FileName must be supplied'                    
 select  @comment                   
 return -99                    
end                    
            
if (ISNULL(@DocumentType,'') ='')            
Begin            
 SET @DocumentType = '(Not specified)'            
end            
                
if (ISNULL(@AttachmentID,0)> 0)                
begin                       
 if NOT EXISTS( Select 1 from Attachment where AttachmentID = @AttachmentID)             
 begin          
  set @comment='AttachmentID ['+ CAST(@AttachmentID as nvarchar(10)) + '] is not valid'                    
  select  @comment                   
  return -99          
 end          
end               
        
         
        
if Isnull(@comment,'') = ''                  
begin                     
                    
if isnull( @AttachmentID,0)>0 and @Remove=1                    
 begin                    
  delete Attachment where AttachmentID=@AttachmentID           
  select 'OK' Result                    
  return 0                    
 end            
          
SET @AttachmentURL = ISNULL(dbo.fn_GetParameter('ATTACHMENTS_URI',0,1033),'')                        
if isnull(@AttachmentURL,'')<>''  AND isnull(@FileName,'')<>''                    
begin                      
 SET @AttachmentURL =  @AttachmentURL + '/' + @FileName                      
end                      
                  
if isnull(@AudienceGroup,'')<>''                    
begin                    
 select @AudienceID = mc.QFMMembershipGroupID from QFMMembershipGroup mc where mc.[Name]=@AudienceGroup                    
 if @AudienceID is null                    
  set @comment=@comment+ ',Audience Group ['+ @AudienceGroup+ '] is not valid'                    
                      
end                    
                    
if isnull(@EditorGroup,'')<>''                    
begin                    
 select @EditorsID = mc.QFMMembershipGroupID from QFMMembershipGroup mc where mc.[Name]=@EditorGroup                    
 if @EditorsID is null                    
  set @comment=@comment+ ',Editor Group ['+ @EditorGroup+ '] is not valid'                    
                      
end                    
                  
select @DocumentTypeID = DocumentTypeID from DocumentType dt where dt.DisplayName=@DocumentType                    
 if @DocumentTypeID is null       
 Begin      
  set @comment=@comment+ ',Document Type ['+ @DocumentType+ '] is not valid'          
  select  @comment                   
  return -99          
 END      
      
If (@EntityType = 'Geography')          
Begin          
 --what level is it?          
 --reset EntityType based on Level          
 SET @EntityType = (Select CASE           
    WHEN Level= 1 THEN  'Site Geography'           
    WHEN Level= 2 THEN  'Location'            
    WHEN Level= 3 THEN  'Unit'            
    WHEN Level= 4 THEN  'Partition' END           
 from Geography where ExportValue =@LookupValue)                    
End          
   
If (@EntityType = 'Schedule Activity')          
Begin  
	IF (ISNULL(@LookupValue,'') <> '')
	BEGIN
		DECLARE @ScheduleActivityList NVARCHAR(max)

		SELECT  @ScheduleActivityList = STUFF((SELECT ',' + CAST(ScheduleActivityID AS NVARCHAR(20)) 
				FROM ScheduleActivity  Where Description = @LookupValue
				FOR XML PATH('')) ,1,1,'')  
	END
End  
If (@EntityType = 'Schedule')          
Begin  
	IF (ISNULL(@LookupValue,'') <> '')
	BEGIN
		DECLARE @ScheduleList NVARCHAR(max)

		SELECT  @ScheduleList = STUFF((SELECT ',' + CAST(ScheduleID AS NVARCHAR(20)) 
				FROM Schedule  Where Description = @LookupValue
				FOR XML PATH('')) ,1,1,'') 
	END
End  
 BEGIN TRY                          
 exec LookupEntityIDUsingXRef   @EntityType ,@LookupValue, @entityID out, @msg out  
 if isnull(@entityID,'')=''  
 BEGIN
  --set @comment=CASE WHEN @comment <> '' THEN  @comment+ ','+@msg ELSE @msg END  
  SET @Comment = @Comment + 'Invalid lookup value ['+ @LookupValue + '] '
  select  @comment                   
  return -99  
End
END TRY                      
BEGIN CATCH                        
 SET @Comment = @Comment + 'Invalid lookup value ['+ @LookupValue + '] '                    
 Print ERROR_MESSAGE()  
   select  @comment                   
   RETURN -99  
END CATCH                          
                    
select @FuncAreaID = et.AttachmentAreaID  from EntityType et where (et.UserName=@EntityType or et.Name=@EntityType )                    

If (@EntityType = 'Schedule Activity')          
Begin  
		 
		 EXEC Tool_WebImportScheduleActivityAttachment   
		 @AttachmentID , 
		 @FileName , 
		 @ScheduleActivityList , 
		 @Caption,
		 @Remarks,
		 @DocumentTypeID ,                    
		 @FuncAreaID ,                  
		 @AudienceID ,                   
		 @EditorsID ,                   
		 @AttachmentURL ,                        
		 @EntityID ,              
		 @StartDateUTC ,             
		 @EndDateUTC,             
		 @Metadata ,
		 @SystemMetaDatatags ,
		 @returnComment OUTPUT

		 IF (ISNULL(@returnComment,'') <> '')
		 BEGIN
           IF (@returnComment = 'OK')
		   BEGIN
				SELECT N'OK' Result                    
				RETURN 0   
		   END
		   ELSE
           BEGIN
				SELECT substring(@returnComment,1,len(@returnComment)-1)   
			  RETURN -99
		  End
		 End 
 RETURN
End  
If (@EntityType = 'Schedule')          
Begin  
		
		 EXEC Tool_WebImportScheduleAttachment   
		 @AttachmentID , 
		 @FileName , 
		 @ScheduleList , 
		 @Caption,
		 @Remarks,
		 @DocumentTypeID ,                    
		 @FuncAreaID ,                  
		 @AudienceID ,                   
		 @EditorsID ,                   
		 @AttachmentURL ,                        
		 @EntityID ,              
		 @StartDateUTC ,             
		 @EndDateUTC,             
		 @Metadata ,
		 @SystemMetaDatatags ,
		 @returnComment OUTPUT

		 IF (ISNULL(@returnComment,'') <> '')
		 BEGIN
           IF (@returnComment = 'OK')
		   BEGIN
				SELECT N'OK' Result                    
				RETURN 0   
		   END
		   ELSE
           BEGIN
				SELECT substring(@returnComment,1,len(@returnComment)-1)   
			  RETURN -99
		  End
		 End 
 RETURN
End                      
if ISNULL(@AttachmentID,0) =0        
Begin        
 select @AttachmentID =AttachmentID from Attachment a where Source=@FileName and @entityID=a.AttachmentRef and @FuncAreaID=a.FuncAreaID                    
end                    
if  @AttachmentID IS not null          
Begin        
 SELECT @Revision = a.Revision from attachment a where a.AttachmentID =@AttachmentID                    
End         
        
if isnull(@Revision,0)>0                     
  set @comment=@comment+ ',Cannot update an attachment link for file which is already uploaded'                    
                    
                  
            
if  isnull( @AttachmentID,0)=0 -- add                    
BEGIN                    
 EXEC [dbo].[qfm_GetKeyValue] @BaseTableName=N'Attachment',@Increment=1,@NextKeyID = @AttachmentID output;                    
                    
 insert into Attachment (DocumentTypeID, Name,AttachmentID,AttachmentTypeID,AttachmentTypeName, Source, FuncAreaID,AttachmentRef, AudienceGroupID, AuthorGroupID, EndDate,                 
 StartDate, Remarks, MetaData, SystemMetaDataTags, Revision,InsertUser,InsertStamp,[Path] )                     
 values (@DocumentTypeID,@Caption,@AttachmentID,4,'URL', @FileName, @FuncAreaID,@EntityID, @AudienceID,@EditorsID, @EndDateUTC, @StartDateUTC, @Remarks, @MetaData, @SystemMetaDataTags, 0,'swgimport', GETUTCDATE(),@AttachmentURL)                    
 SELECT N'OK' Result                    
 RETURN 0     
                    
end                    
else                    
 update Attachment set                     
 DocumentTypeID=@DocumentTypeID,                    
 Source=@FileName,                    
 Name=@Caption,                    
 FuncAreaID= @FuncAreaID,                    
 AttachmentRef=@EntityID,                     
   AudienceGroupID= @AudienceID,                    
   AuthorGroupID= @EditorsID,                     
   EndDate=@EndDateUTC,                    
   StartDate= @StartDateUTC,                     
   Remarks=@Remarks,                     
   MetaData=@MetaData,                     
   SystemMetaDataTags= @SystemMetaDataTags  ,                  
   UpdateUser='swgimport',                  
   UpdateStamp = GETUTCDATE()                  
 where AttachmentID=@AttachmentID                    
SELECT N'OK' Result                    
 RETURN 0                    
end                    
else                    
 select substring(@comment,1,len(@Comment)-1)                    
 return -99
